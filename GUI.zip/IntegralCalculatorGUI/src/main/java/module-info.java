module com.mycompany.integralcalculatorgui {
    requires javafx.controls;
    exports com.mycompany.integralcalculatorgui;
    requires javaluator;
}
